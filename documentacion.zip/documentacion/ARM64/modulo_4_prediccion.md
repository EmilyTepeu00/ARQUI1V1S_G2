
# Módulo 4: Predicción de Próximo Valor

## Proyecto

**Invernadero Inteligente IoT**
Curso: Arquitectura de Computadoras y Ensambladores 1 (ACYE1)

**Responsable:** Diana Santizo

---

## Descripción General

El Módulo 4 tiene como objetivo realizar una predicción simple del próximo valor de una variable obtenida desde el archivo de lecturas del sistema de monitoreo del invernadero.

La predicción se basa en una tendencia lineal calculada a partir del valor inicial y el valor final de una serie de datos almacenados en el archivo `lecturas.csv`.

El módulo es implementado en lenguaje ensamblador ARM64 y genera un archivo de salida con los resultados obtenidos.

---

## Archivo de Entrada

El módulo utiliza como fuente de datos el archivo:

```text
lecturas.csv
```

Este archivo contiene las lecturas históricas de los sensores del sistema.

---

## Selección de Columna

El número de columna a procesar es recibido como argumento desde el programa principal desarrollado en Python.

Las columnas disponibles son:

| Columna | Variable            |
| ------- | ------------------- |
| 1       | ID                  |
| 2       | Temperatura         |
| 3       | Humedad del Aire    |
| 4       | Humedad del Suelo 1 |
| 5       | Humedad del Suelo 2 |
| 6       | Luz                 |
| 7       | Gas                 |

Si no se recibe ningún argumento, el módulo utiliza por defecto la columna 2 correspondiente a la temperatura.

---

## Procesamiento de Datos

El procedimiento realizado por el módulo es el siguiente:

1. Leer los datos de la columna seleccionada.
2. Obtener el primer valor de la serie.
3. Obtener el último valor de la serie.
4. Calcular la diferencia total entre ambos valores.
5. Calcular el promedio de cambio.
6. Estimar el siguiente valor utilizando una tendencia lineal simple.
7. Generar un archivo de resultados.

Durante la lectura del archivo CSV, los valores decimales son truncados, conservando únicamente su parte entera.

Ejemplos:

| Valor leído | Valor utilizado |
| ----------- | --------------- |
| 23.9        | 23              |
| 18.45       | 18              |
| 42.0        | 42              |
| 7.99        | 7               |

---

## Fórmulas Utilizadas

### Valor Inicial

```text
Inicial = datos[0]
```

### Valor Final

```text
Final = datos[29]
```

### Diferencia Total

```text
Diferencia = Final - Inicial
```

### Promedio de Cambio

```text
Promedio = Diferencia / 29
```

Se utilizan 29 intervalos debido a que existen 30 registros.

### Predicción

```text
Predicción = Final + Promedio
```

---

## Estructura de Salida

El módulo genera el archivo:

```text
resultado_prediccion.txt
```

El contenido tiene el siguiente formato:

```text
MODULE=PREDICTION
INITIAL_VALUE=20
FINAL_VALUE=35
TOTAL_DIFF=15
AVG_CHANGE=0
NEXT_VALUE=35
```

---

## Variables Principales

| Registro | Descripción          |
| -------- | -------------------- |
| x19      | Valor inicial        |
| x22      | Valor final          |
| x23      | Diferencia total     |
| x24      | Promedio de cambio   |
| x25      | Predicción calculada |

---

## Funciones Utilizadas

### leer_datos

Lee el archivo `lecturas.csv`, extrae la columna seleccionada y almacena los valores en el arreglo `datos`.

### ascii_a_int

Convierte una cadena de caracteres numérica a un valor entero.

### int_a_ascii

Convierte un valor entero a una cadena de caracteres para su escritura en el archivo de salida.

### copiar_a_buffer

Copia cadenas de texto al buffer utilizado para construir el contenido final del archivo.

### formatear_numero

Gestiona la conversión y presentación de números positivos y negativos antes de escribirlos en la salida.

---

## Complejidad

El algoritmo realiza una única lectura de los datos y una cantidad constante de operaciones aritméticas.

Complejidad temporal:

```text
O(n)
```

donde:

```text
n = cantidad de registros leídos
```

Complejidad espacial:

```text
O(n)
```

debido al almacenamiento temporal de los datos en memoria.

---

## Resultado Esperado

El módulo proporciona una estimación sencilla del siguiente valor esperado para la variable seleccionada, utilizando una tendencia lineal basada en el comportamiento observado entre el primer y el último registro disponible.

Esta predicción permite obtener una aproximación rápida del comportamiento futuro de los sensores monitoreados por el sistema de invernadero inteligente.

---

## Prueba GDB
![](evidencia_gdb/100.png)
![](evidencia_gdb/101.png)
![](evidencia_gdb/200.png)
![](evidencia_gdb/201.png)
![](evidencia_gdb/202.png)
![](evidencia_gdb/203.png)
![](evidencia_gdb/204.png)
![](evidencia_gdb/205.png)
![](evidencia_gdb/206.png)
![](evidencia_gdb/207.png)
![](evidencia_gdb/208.png)

**Autor:** Diana Santizo
**Módulo:** Predicción de Próximo Valor
**Lenguaje:** ARM64 Assembly
**Proyecto:** Invernadero Inteligente IoT
